/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service.menu;

import service.inter.menu.MenuRegisterServiceInter;

/**
 *
 * @author Igrar
 */
public class MenuRegisterService implements MenuRegisterServiceInter {

    @Override
    public void processLogic() {
        System.out.println("Register Menu");
    }

}
